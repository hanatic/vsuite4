// VAR DECLARATION

var readyalert = true
var closec = false
var clipboardd = false
var ctrlkeypressed = false

// END OF VAR DECLARATION

// KEYBOARD SHORTCUTS

document.onkeyup = function(e) {
    if (e.ctrlKey && e.key == 'b') {
      searchgoogle(false);
    } else if (e.ctrlKey && e.key == 'B'){
      searchgoogle(true);
    }
    ctrlkeypressed = false
    document.getElementById('googlebtn').innerHTML = '<strong>Search on Google </strong><small>Ctrl + B</small>'
    document.getElementById('selectbtn').innerHTML = '<strong>Select All </strong><small>Cmd/Ctrl + A</small>'
    document.getElementById('reloadbtn').innerHTML = '<strong>Reload </strong><small>Cmd/Ctrl + R</small>'
  };

document.onkeydown = function(e){
    if (e.key == 's'){
        ctrlkeypressed = true
        document.getElementById('googlebtn').innerHTML = '<strong>Search on Bing </strong><small>Ctrl + Shift + B</small>'
        document.getElementById('selectbtn').innerHTML = '<strong>Deselect All </strong><small>Ctrl + B</small>'
        document.getElementById('reloadbtn').innerHTML = '<strong>Reload in new tab </strong><small>Ctrl + B</small>'
    } else{
        ctrlkeypressed = false
    }
}

// END OF KEYBOARD SHORTCUTS

// CONTEXT MENU (REMEMBER TO ADD NEW BUTTONS OR WEIRD THINGS WILL HAPPEN....!)

document.addEventListener('contextmenu', function(event){
    event.preventDefault()
    var contextElement = document.getElementById("context-menu");
    contextElement.style.top = event.clientY + "px";
    contextElement.style.left = event.clientX + "px";
    contextElement.className = 'contextmenu'
    document.getElementById('copybtn').style.display = 'inline-block'
    document.getElementById('googlebtn').style.display = 'inline-block'
    document.getElementById('reloadbtn').style.display = 'inline-block'
    document.getElementById('selectbtn').style.display = 'inline-block'
    document.getElementById('pastebtn').style.display = 'inline-block'
    document.getElementById('backbtn').style.display = 'inline-block'
    document.getElementById('forwardbtn').style.display = 'inline-block'
    document.getElementById('printbtn').style.display = 'inline-block'
    document.getElementById('hrbtn').style.display = 'block'
    setTimeout(function(){closec = true}, 2000)
})

document.addEventListener("click", function(){
    closecontext()
  });

function closecontext(){
    document.getElementById("context-menu").className = 'contextmenuhidden'
    document.getElementById('copybtn').style.display = 'none'
    document.getElementById('googlebtn').style.display = 'none'
    document.getElementById('reloadbtn').style.display = 'none'
    document.getElementById('selectbtn').style.display = 'none'
    document.getElementById('hrbtn').style.display = 'none'
    document.getElementById('pastebtn').style.display = 'none'
    document.getElementById('forwardbtn').style.display = 'none'
    document.getElementById('backbtn').style.display = 'none'
    document.getElementById('printbtn').style.display = 'none'
  }

// END OF CONTEXT MENU

// EMOJI AND SYMBOLS MENU

function emojimenu(){
    document.getElementById('emojimenu').className = 'contextmenu'
}

function hideemojimenu(){
    document.getElementById('emojimenu').className = 'contextmenu'
}



// END OF EMOJI AND SYMBOLS MENU

// LOGIN. NOT YET PROPERLY DOING ITS THING BUT HEY HO, IT DOES SOMETHING

function login(email, password){    
    if (email == 'test@test.com' && password == 'password1'){  
        var audio = new Audio('ringtones/vsuite_texttone.mp3');
        audio.play();
        window.open('home.html', '_self')
    } else{
        alerrt('Something went wrong', "We couldn't log you in - check your credentials.")
    }
}

// END OF LOGIN

// INTERNAL ALERTS AND NOTIFICATIONS

function alerrt(title, body){
     if (readyalert == true){   
        readyalert = false
        document.getElementById('alertbox').className = 'alertbox'
        document.getElementById('alerttitle').innerHTML = title
        document.getElementById('alertbody').innerHTML = body
        document.getElementById('alerttitle').style.display = 'inline-block'
        document.getElementById('alertbody').style.display = 'inline-block'
        document.getElementById('alertbtn').style.display = 'inline-block'
        document.getElementById('icon').href = 'logo_dot.png'
        var audio = new Audio('ringtones/vsuite_alerttone.mov');
        audio.play();
     } else {alerrt(title, body)}
}

function alertclose(){
    document.getElementById('alertbox').className = 'alerthidden'
    document.getElementById('alerttitle').style.display = 'none'
    document.getElementById('alertbody').style.display = 'none'
    document.getElementById('alertbtn').style.display = 'none'
    document.getElementById('icon').href = 'logo.png'
    readyalert = true

}

// END OF INTERNAL ALERTS AND NOTIFICATIONS

// CLIPBOARD ACTIONS


function clipboard_copyto(value) {
    if (value){    
        var tempInput = document.createElement("input");
        tempInput.value = value;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("cut");
        document.body.removeChild(tempInput);
    }

}


function paste(){
    alerrt('Coming soon', "We're working on the Paste feature. In the meantime please use Cmd/Ctrl + V to paste using your system.")
}

// END OF CLIPBOARD ACTIONS

// CONTEXT MENU AND KEYBOARD SHORTCUT ACTIONS

function searchgoogle(bingbool){
  if (bingbool == true){
      window.open('https://bing.com/search?q=' + getSelection(), '_blank')
  } else {
      window.open('https://google.com/search?q=' + getSelection(), '_blank')
  }

}


// END OF CONTEXT MENU AND KEYBOARD SHORTCUT ACTIONS

